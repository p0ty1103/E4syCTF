# Hello, Reversing!

## Question
フラグはファイルに埋め込まれてるんだって！

## Points
* 100 pt
## Flag
* `E4syCTF{h4rdc0ded_str1ng_1s_E4sy!}`
## Tags
* `author: Pochix1103`
* `Easy`