#include<stdio.h>

int main(void){
	char flag[] = "E4syCTF{h4rdc0ded_str1ng_1s_E4sy!}";

	printf("Flag is Secret!\nCan you find it?\n");

	return 0;

}