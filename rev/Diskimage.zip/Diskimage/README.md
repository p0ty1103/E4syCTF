# Diskimage

## Question
Pls found the flag!!

## Points
* 300 pt
## Flag
* `E4syCTF{7he_Fl4g_l13s_w1thin_th3_im4ge}`
## Tags
* `author: Pochix1103`
* `Medium`