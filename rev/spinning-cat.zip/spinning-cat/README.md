# spinning-cat

## Question
Apparently, this program was created by a certain famous cat.

## Points
* 100 pt
## Flag
* `E4syCTF{OIIA-OIIA_oII4-0114_c4t_i5_5pinnin9}`
## Tags
* `author: JUCK`
* `Easy`