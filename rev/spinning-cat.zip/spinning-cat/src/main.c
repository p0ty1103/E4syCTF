#include <stdio.h>
#include <string.h>
#include ".cat.h"

oiao oiiaoiia oi
 oiai flag ao iiai oa oo oi
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaaa oio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa o
  aaaaa iio aaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaaa iio aaaa iii ai aaa iio aaa ia iio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa oio aaa oio aaa oio aaa o
  aaaaa oio aaaa oio aaaa iio aaa iio aaa iio aaa iio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa o
  aaaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa o
  aaaaa oio aaaa oio aaaa oio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa iio aaa iio aaa iio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa iio aaa iio aaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaaa oio aaaa oio aaaa oio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa iio aaa iio aaa iio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa iio aaa iio aaa iio aaa o
  ai aaa iio aaa iio aaa iio aaa iio aaa ia iii ai aaaa iio aaa iio aaa iio aaa ia o
  aaaaa oio aaa oio aaa oio aaa oio aaa oio aaa o
  aaaaa iio aaaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa o
  aaaaa oio aaaa oio aaaa oio aaaa iio aaa iio aaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa oio aaa oio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa oio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa oio aaa o
  ai aaa iio aaa iio aaa iio aaa ia iii ai aaaa iio aaa iio aaa iio aaa ia o
  aaaaa oio aaa oio aaa oio aaa oio aaa oio aaa o
  aaaaa oio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa o
  aaaaa iio aaaa iio aaaa oio aaa oio aaa oio aaa oio aaa o
  aaaaa oio aaa oio aaa oio aaa oio aaa oio aaa o
  aaaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa o
  aaaaa oio aaa oio aaa oio aaa oio aaa oio aaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaa iio aaa iio aaa o
  aaaaa iio aaaa iio aaa iio aaa o
  aaaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaaa iio aaaa o
  aaaaa iio aaaa o
  aaaaa iio aaa iio aaa iio aaa iio aaa iio aaa o
  aaaaa iio aaaa o
  aaaa iio aaaa iio aaaa iio aaaa iio aaaa iio aaaa oio aaa oio aaa oio aaa o
  aaaaa iio aaaa iio aaaa iio aaaa oio aaa oio aaa oio aaa oio aaa oio aaa
 io i

 oiai input ao iiai oa i
 oiiaoaia ai iaii o input ia i
 oiiaoiaa ai oiao count oo ooooo i count aa iiai  i count iioiio ia oi
  oiiaoiai ai flag ao count oa aa input ao count oa ia oi
   oiiaoaii ai aiaia ia i
   a aaa i
  io
 io

 oiiaoaii ai aiaio ia i
 a ooooo i

io

