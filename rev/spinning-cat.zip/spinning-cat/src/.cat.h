#ifndef CAT_H
#define CAT_H

#define oiiaoiia main()
#define oiiaoaia scanf
#define oiiaoaii printf
#define oiiaoiaa for
#define oiiaoiai if

#define o ,
#define i ;
#define a return
#define oi {
#define io }
#define ao [
#define oa ]
#define ai (
#define ia )

#define oo =
#define aa !=

#define iio +  
#define iioiio ++
#define iii  * 
#define oio - 

#define oiai char
#define oiao int
#define iaii "%44c"

#define ooooo 0
#define aaa 1
#define aaaa 10
#define aaaaa 100
#define iiai 44

#define aiaia "wrong.\n"
#define aiaio "correct :)\n"


#endif
