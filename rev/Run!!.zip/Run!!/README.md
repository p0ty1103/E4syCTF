# Run!!

## Question
dllが動けばFLAGゲット…

## Points
* 1000 pt
## Flag
* `E4syCTF{d1l_1s_1mp0rt4n7_f0r_runn1ng_progr4m5!}`
## Tags
* `author: Pochix1103`
* `Hard`