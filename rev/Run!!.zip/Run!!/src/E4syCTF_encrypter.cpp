#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ROUNDS 20
#define BLOCK_SIZE 64

const char* flag = "E4syCTF{d1l_1s_1mp0rt4n7_f0r_runn1ng_progr4m5!}";
const char* decrypt_key = "E4syCTF";

BYTE fileKey[32] = {
    0x7A, 0x6F, 0x21, 0xB8, 0xCC, 0x34, 0x9D, 0xE0,
    0x54, 0xAD, 0x8E, 0x16, 0x93, 0xFA, 0x42, 0x77,
    0xC1, 0x09, 0x38, 0x6D, 0xA5, 0x51, 0xEB, 0x2F,
    0xD2, 0x03, 0xBE, 0x19, 0x68, 0xCD, 0x7E, 0xF5
};

BYTE nonce[12] = {
    0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0,
    0x11, 0x22, 0x33, 0x44
};

DWORD counter = 1;

typedef struct {
    DWORD state[16];
} Chacha20;

DWORD ROTL32(DWORD value, int shift) {
    return (value << shift) | (value >> (32 - shift));
}

void quarter_round(DWORD* a, DWORD* b, DWORD* c, DWORD* d) {
    *a = (*a + *b) & 0xFFFFFFFF; *d ^= *a; *d = ROTL32(*d, 16);
    *c = (*c + *d) & 0xFFFFFFFF; *b ^= *c; *b = ROTL32(*b, 12);
    *a = (*a + *b) & 0xFFFFFFFF; *d ^= *a; *d = ROTL32(*d, 8);
    *c = (*c + *d) & 0xFFFFFFFF; *b ^= *c; *b = ROTL32(*b, 7);
}

void init_state(Chacha20* chacha20, const BYTE* key, DWORD counter) {
    chacha20->state[0] = 0x73794534;  // "E4ys" (little endian)
    chacha20->state[1] = 0x46544379;  // "yCTF" (little endian)  
    chacha20->state[2] = 0x7379453f;  // "?E4s" (little endian)
    chacha20->state[3] = 0x46544379;  // "yCTF" (little endian)
    chacha20->state[4] = ((DWORD*)key)[0];
    chacha20->state[5] = ((DWORD*)key)[1];
    chacha20->state[6] = ((DWORD*)key)[2];
    chacha20->state[7] = ((DWORD*)key)[3];
    chacha20->state[8] = ((DWORD*)key)[4];
    chacha20->state[9] = ((DWORD*)key)[5];
    chacha20->state[10] = ((DWORD*)key)[6];
    chacha20->state[11] = ((DWORD*)key)[7];
    chacha20->state[12] = counter;
    chacha20->state[13] = ((DWORD*)nonce)[0];
    chacha20->state[14] = ((DWORD*)nonce)[1];
    chacha20->state[15] = ((DWORD*)nonce)[2];
}

void chacha20_block(Chacha20* chacha20) {
    DWORD initial_state[16];

    for (int i = 0; i < 16; i++) {
        initial_state[i] = chacha20->state[i];
    }

    for (int i = 0; i < ROUNDS / 2; i++) {

        quarter_round(&chacha20->state[0], &chacha20->state[4], &chacha20->state[8], &chacha20->state[12]);
        quarter_round(&chacha20->state[1], &chacha20->state[5], &chacha20->state[9], &chacha20->state[13]);
        quarter_round(&chacha20->state[2], &chacha20->state[6], &chacha20->state[10], &chacha20->state[14]);
        quarter_round(&chacha20->state[3], &chacha20->state[7], &chacha20->state[11], &chacha20->state[15]);

        quarter_round(&chacha20->state[0], &chacha20->state[5], &chacha20->state[10], &chacha20->state[15]);
        quarter_round(&chacha20->state[1], &chacha20->state[6], &chacha20->state[11], &chacha20->state[12]);
        quarter_round(&chacha20->state[2], &chacha20->state[7], &chacha20->state[8], &chacha20->state[13]);
        quarter_round(&chacha20->state[3], &chacha20->state[4], &chacha20->state[9], &chacha20->state[14]);
    }

    for (int i = 0; i < 16; i++) {
        chacha20->state[i] = (chacha20->state[i] + initial_state[i]) & 0xFFFFFFFF;
    }
}

void xor_data(BYTE* key_stream, const char* originDat, unsigned char* encDat, size_t datlen) {
    for (size_t i = 0; i < datlen; i++) {
        encDat[i] = originDat[i] ^ key_stream[i];
    }
}

void chacha20_encrypt(BYTE* key, DWORD* counter, const char* originDat, unsigned char* encDat, size_t datlen) {
    Chacha20 chacha20;
    int blocks = (int)((datlen + BLOCK_SIZE - 1) / BLOCK_SIZE);

    for (int i = 0; i < blocks; i++) {
        init_state(&chacha20, key, *counter + (DWORD)i);
        chacha20_block(&chacha20);
        if (i == blocks - 1) {
            xor_data((BYTE*)&chacha20.state, originDat + i * BLOCK_SIZE, encDat + i * BLOCK_SIZE, datlen % BLOCK_SIZE);
        }
        else {
            xor_data((BYTE*)&chacha20.state, originDat + i * BLOCK_SIZE, encDat + i * BLOCK_SIZE, BLOCK_SIZE);
        }
    }
}

void print_encrypted_array(unsigned char* data, size_t len) {
    printf("// Encrypted Flag (for DLL embedding)\n");
    printf("BYTE encrypted_flag[%zu] = {\n    ", len);
    
    for (size_t i = 0; i < len; i++) {
        printf("0x%02X", data[i]);
        if (i < len - 1) {
            printf(", ");
            if ((i + 1) % 12 == 0) {
                printf("\n    ");
            }
        }
    }
    printf("\n};\n\n");
    
    printf("size_t encrypted_flag_len = %zu;\n\n", len);
    
    printf("// ChaCha20 Parameters\n");
    printf("BYTE chacha20_key[32] = {\n    ");
    for (int i = 0; i < 32; i++) {
        printf("0x%02X", fileKey[i]);
        if (i < 31) {
            printf(", ");
            if ((i + 1) % 8 == 0) {
                printf("\n    ");
            }
        }
    }
    printf("\n};\n\n");
    
    printf("BYTE chacha20_nonce[12] = {\n    ");
    for (int i = 0; i < 12; i++) {
        printf("0x%02X", nonce[i]);
        if (i < 11) printf(", ");
    }
    printf("\n};\n\n");
    
    printf("DWORD chacha20_counter = %lu;\n\n", (unsigned long)counter);
    
    printf("// Decrypt key: \"%s\"\n", decrypt_key);
}

int main() {
    size_t flag_len = strlen(flag);
    unsigned char* encrypted = (unsigned char*)malloc(flag_len + 1);
    
    printf("Original flag: %s\n", flag);
    printf("Decrypt key: %s\n", decrypt_key);
    printf("Flag length: %zu\n\n", flag_len);
    
    chacha20_encrypt(fileKey, &counter, flag, encrypted, flag_len);
    
    printf("=== Code for DLL ===\n\n");
    print_encrypted_array(encrypted, flag_len);
    
    unsigned char* decrypted = (unsigned char*)malloc(flag_len + 1);
    chacha20_encrypt(fileKey, &counter, (char*)encrypted, decrypted, flag_len);
    decrypted[flag_len] = '\0';
    
    printf("=== Verification ===\n");
    printf("Decrypted: %s\n", decrypted);
    printf("Match: %s\n", strcmp(flag, (char*)decrypted) == 0 ? "YES" : "NO");
    
    free(encrypted);
    free(decrypted);
    
    return 0;
}