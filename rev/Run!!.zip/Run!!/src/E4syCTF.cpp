#include <windows.h>
#include <string.h>

#define ROUNDS 20
#define BLOCK_SIZE 64

typedef struct {
    DWORD state[16];
} Chacha20;

DWORD ROTL32(DWORD value, int shift) {
    return (value << shift) | (value >> (32 - shift));
}

void quarter_round(DWORD* a, DWORD* b, DWORD* c, DWORD* d) {
    *a = (*a + *b) & 0xFFFFFFFF; *d ^= *a; *d = ROTL32(*d, 16);
    *c = (*c + *d) & 0xFFFFFFFF; *b ^= *c; *b = ROTL32(*b, 12);
    *a = (*a + *b) & 0xFFFFFFFF; *d ^= *a; *d = ROTL32(*d, 8);
    *c = (*c + *d) & 0xFFFFFFFF; *b ^= *c; *b = ROTL32(*b, 7);
}

void init_state(Chacha20* chacha20, const BYTE* key, const BYTE* nonce, DWORD counter) {
    chacha20->state[0] = 0x73794534;  // "E4ys" (little endian)
    chacha20->state[1] = 0x46544379;  // "yCTF" (little endian)  
    chacha20->state[2] = 0x7379453f;  // "?E4s" (little endian)
    chacha20->state[3] = 0x46544379;  // "yCTF" (little endian)
    chacha20->state[4] = ((DWORD*)key)[0];
    chacha20->state[5] = ((DWORD*)key)[1];
    chacha20->state[6] = ((DWORD*)key)[2];
    chacha20->state[7] = ((DWORD*)key)[3];
    chacha20->state[8] = ((DWORD*)key)[4];
    chacha20->state[9] = ((DWORD*)key)[5];
    chacha20->state[10] = ((DWORD*)key)[6];
    chacha20->state[11] = ((DWORD*)key)[7];
    chacha20->state[12] = counter;
    chacha20->state[13] = ((DWORD*)nonce)[0];
    chacha20->state[14] = ((DWORD*)nonce)[1];
    chacha20->state[15] = ((DWORD*)nonce)[2];
}

void chacha20_block(Chacha20* chacha20) {
    DWORD initial_state[16];
    for (int i = 0; i < 16; i++) initial_state[i] = chacha20->state[i];

    for (int i = 0; i < ROUNDS / 2; i++) {
        quarter_round(&chacha20->state[0], &chacha20->state[4], &chacha20->state[8], &chacha20->state[12]);
        quarter_round(&chacha20->state[1], &chacha20->state[5], &chacha20->state[9], &chacha20->state[13]);
        quarter_round(&chacha20->state[2], &chacha20->state[6], &chacha20->state[10], &chacha20->state[14]);
        quarter_round(&chacha20->state[3], &chacha20->state[7], &chacha20->state[11], &chacha20->state[15]);
        quarter_round(&chacha20->state[0], &chacha20->state[5], &chacha20->state[10], &chacha20->state[15]);
        quarter_round(&chacha20->state[1], &chacha20->state[6], &chacha20->state[11], &chacha20->state[12]);
        quarter_round(&chacha20->state[2], &chacha20->state[7], &chacha20->state[8], &chacha20->state[13]);
        quarter_round(&chacha20->state[3], &chacha20->state[4], &chacha20->state[9], &chacha20->state[14]);
    }

    for (int i = 0; i < 16; i++) chacha20->state[i] = (chacha20->state[i] + initial_state[i]) & 0xFFFFFFFF;
}

void chacha20_process_data(const BYTE* key, const BYTE* nonce, DWORD counter, const BYTE* input, BYTE* output, size_t data_len) {
    Chacha20 chacha20;
    size_t offset = 0;

    while (offset < data_len) {
        init_state(&chacha20, key, nonce, counter + (DWORD)(offset / BLOCK_SIZE));
        chacha20_block(&chacha20);

        size_t remaining = data_len - offset;
        size_t block_len = (remaining < BLOCK_SIZE) ? remaining : BLOCK_SIZE;

        for (size_t i = 0; i < block_len; i++) {
            output[offset + i] = input[offset + i] ^ ((BYTE*)chacha20.state)[i];
        }
        offset += BLOCK_SIZE;
    }
}

BYTE encrypted_flag[47] = {
    0x1C, 0x05, 0xB7, 0x4B, 0xBD, 0x50, 0xE2, 0x12, 0x9D, 0x82, 0x4F, 0x63, 
    0x6C, 0xFB, 0x9B, 0x2E, 0xCD, 0x5B, 0x7C, 0x11, 0x2A, 0x54, 0xAD, 0xAB, 
    0x44, 0x43, 0x1D, 0xD2, 0xD0, 0x1F, 0xCE, 0x0A, 0x1E, 0xB8, 0xAC, 0x33, 
    0x08, 0xA5, 0x82, 0xCC, 0x1E, 0x2D, 0x57, 0x74, 0xDF, 0xA1, 0xDD
};
size_t encrypted_flag_len = 47;

BYTE chacha20_key[32] = {
    0x7A, 0x6F, 0x21, 0xB8, 0xCC, 0x34, 0x9D, 0xE0, 
    0x54, 0xAD, 0x8E, 0x16, 0x93, 0xFA, 0x42, 0x77, 
    0xC1, 0x09, 0x38, 0x6D, 0xA5, 0x51, 0xEB, 0x2F, 
    0xD2, 0x03, 0xBE, 0x19, 0x68, 0xCD, 0x7E, 0xF5
};

BYTE chacha20_nonce[12] = {
    0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0, 0x11, 0x22, 0x33, 0x44
};

DWORD chacha20_counter = 1;

extern "C" __declspec(dllexport)
BOOL check_and_set_flag(const char* input_key) {
    const char* correct_key = "E4syCTF";

    if (input_key == NULL || strcmp(input_key, correct_key) != 0) {
        return FALSE;
    }

    char decrypted_flag[128];

    chacha20_process_data(
        chacha20_key,
        chacha20_nonce,
        chacha20_counter,
        encrypted_flag,
        (BYTE*)decrypted_flag,
        encrypted_flag_len
    );
    decrypted_flag[encrypted_flag_len] = '\0';

    SetEnvironmentVariableA("E4syCTF_FLAG", decrypted_flag);

    return TRUE;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    return TRUE;
}