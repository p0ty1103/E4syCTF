# Common Language

## Question
I LOVE MICROSOFT!!!

## Points
* 100 pt
## Flag
* `E4syCTF{d0tn3t_h4s_4_CLR_50_634utifu1...}`
## Tags
* `author: JUCK`
* `Easy`