# ECC

## Question
ECC with singular curves
<br>
nc ecc-e4syctf.pochix1103.net 7777

## Points
* 700 pt
## Flag
* `E4syCTF{s1n8ul4r_curv3_1s_e4sy_t0_br3ak}`
## Tags
* `author: Pochix1103`
* `Medium`