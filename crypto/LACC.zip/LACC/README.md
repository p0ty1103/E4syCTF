# LACC

## Question
McEliece風の暗号を実装しました。
<br>
`nc lacc-e4syctf.pochix1103.net 13337`
<br>
>※solverは恐らく時間かかる(15分以上)ので同時並行で別の問題解いたほうがいいです…

## Points
* 1500 pt
## Flag
* `E4syCTF{Th1s_1s_n0t_McEl1ec3_but_a_Syndr0me_Dec0d1ng_Pr0bl3m}`
## Tags
* `author: Pochix1103`
* `Hard`