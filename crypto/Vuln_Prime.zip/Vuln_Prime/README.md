# Vuln Prime

## Question
安全な素数を使っているから、このRSAは安全...だよね？
<br>
`nc vulnprime-e4syctf.pochix1103.net 9900`

## Points
* 300 pt
## Flag
* `E4syCTF{Th1s_fl4g_i5_v3ry_vu1n3r4b13}`
## Tags
* `author: Pochix1103`
* `Easy`