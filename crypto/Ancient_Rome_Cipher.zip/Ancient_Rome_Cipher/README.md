# Ancient Rome Cipher

## Question
古代ローマの将軍が使っていた暗号らしい。
<br>
`R4flPGS{P43F4E_P1cu3e_v5_P1n55vp!}`

## Points
* 100 pt
## Flag
* `E4syCTF{C43S4R_C1ph3r_i5_C1a55ic!}`
## Tags
* `author: Pochix1103`
* `Easy`