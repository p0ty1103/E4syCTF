# trick OR flag?

## Question
ฅ^-ﻌ-^ฅ< It's a little early, but Happy Halloween!! I don't want anyone to play tricks on me, but I also don't want to just hand it over so I hid it in my knapsack.

## Points
* 1000 pt
## Flag
* `E4syCTF{JUCK's_delicious_sweets_were_hidden_in_knapsack}`
## Tags
* `author: JUCK`
* `Hard`