# 𝐢𝐭𝐞𝐦 𝐬𝐡𝐨𝐩 I

## Question
お店を開きました！
<br>
` nc item-shop-medium-e4syctf.pochix1103.net 9001`

## Points
* 700 pt
## Flag
* `E4syCTF{h33p_3xpl0it4s10n_1s_diff1cul7_f0r_3eg1nn3r5!}`
## Tags
* `author: Pochix1103`
* `Medium`