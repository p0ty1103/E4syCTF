# Welcome to Pwn

## Question
Pwnの世界へようこそ。
</br>
`nc first-pwn-e4syctf.pochix1103.net 12345`

## Points
* 100 pt
## Flag
* `E4syCTF{My_F1r5t_8uff3r_0verf10w!}`
## Tags
* `author: Pochix1103`
* `Easy`