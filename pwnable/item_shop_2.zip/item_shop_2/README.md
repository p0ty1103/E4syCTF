# 𝐢𝐭𝐞𝐦 𝐬𝐡𝐨𝐩 II

## Question
𝐢𝐭𝐞𝐦 𝐬𝐡𝐨𝐩 Iは脆弱だったのでセキュリティを強化しました！！
<br>
` nc item-shop-hard-e4syctf.pochix1103.net 9002`

## Points
* 1000 pt
## Flag
* `E4syCTF{R0P_15_K1N6_0RW_by_s3cc0mp!!}`
## Tags
* `author: Pochix1103`
* `Hard`