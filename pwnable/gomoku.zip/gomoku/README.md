# Funny Gomoku Game!

## Question
対話形式の五目並べを作ってみました！
<br>
`nc gomoku-e4syctf.pochix1103.net 14000`

## Points
* 400 pt
## Flag
* `E4syCTF{R0P_1s_Fun_G0m0ku_ch4ll3ng3!}`
## Tags
* `author: Pochix1103`
* `Medium`