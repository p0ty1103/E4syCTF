# Secure Note📒

## Question
セキュアなCLIメモを作りました！
<br>
`nc securenote-e4syctf.pochix1103.net 9999`

## Points
* 700 pt
## Flag
* `E4syCTF{s3r1al1z3_w1th_c4ut10n_d34r_fr13nd}`
## Tags
* `author: Pochix1103`
* `Medium`