# Python of Cow

## Question
この牛はPythonで話すらしい。
<br>
https://cowsay-e4syctf.pochix1103.net/?name=Guest

## Points
* 400 pt
## Flag
* `E4syCTF{C4n_Y0u_F1nd_S3rver_S1de_T3mplat3_1nj3c710n?}`
## Tags
* `author: Pochix1103`
* `Medium`