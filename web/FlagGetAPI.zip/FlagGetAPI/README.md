# FlagGetAPI

## Question
情報漏えいしました。
<br>
https://api-e4syctf.pochix1103.net

## Points
* 250 pt
## Flag
* `E4syCTF{D1sc0ver_H1dd3n_AP1_!!}`
## Tags
* `author: Pochix1103`
* `Easy`