# Unauthorized Client

## Question
このサーバーは、特別なクライアントからのアクセスしか受け付けないようだ...
<br>
`curl -i`を使うと楽みたい…
<br>
https://authorize-e4syctf.pochix1103.net

## Points
* 100 pt
## Flag
* `E4syCTF{H3ader_1s_Imp0r74nt!}`
## Tags
* `author: Pochix1103`
* `Easy`